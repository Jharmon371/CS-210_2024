/*
	Jason Harmon
	CS-210
	Professor Thoma
	Corner Grocer
	2/24/2024
*/

#include <iostream>
#include <fstream>
#include <string>
#include <map>
using namespace std;

int main() {
	// creates map and opens files
	map <string, int> itemFrequency;
	std::ifstream inputFile("CS210_Project_Three_Input_File.txt");
	std::ofstream outputFile("frequency.dat");

	// adds 1 when an item shows up on the list 
	string item;
	while (inputFile >> item) {
		++itemFrequency[item];
	}

	// prints the output onto the frequency.dat file
	for (auto i : itemFrequency) {
		outputFile << i.first << " " << i.second << endl;
	}

	bool runMenu = true;
	bool correctInput;
	int userInput;
	string groceryItem;

	// menu loop
	do {

		cout << endl;
		cout << "**********************************************" << endl;
		cout << "*        Please Select A Menu Option         *" << endl;
		cout << "**********************************************" << endl;
		cout << "*  1 - Print item frequency                  *" << endl;
		cout << "*  2 - Print all items and the frequency     *" << endl;
		cout << "*  3 - Print histogram                       *" << endl;
		cout << "*  4 - Exit Program                          *" << endl;
		cout << "**********************************************" << endl;
		cout << endl;

		try {
			std::cin >> userInput;
			cout << endl;

			// if user enters wrong input
			while (std::cin.fail()) {
				std::cin.clear();
				std::cin.ignore(256, '\n');
				cout << "Please enter a valid input." << endl;
				std::cin >> userInput;
				cout << endl;
			}
			if (userInput > 0 && userInput < 5) {
				correctInput = true;
			}
			else {
				throw (userInput);
			}
		}
		catch (...) {
			cout << "Please enter a valid input." << endl;
		}
		// if user selects option 1 on menu
		if (userInput == 1) {
			cout << "*****************************************************************" << endl;
			cout << "* Please enter the item you would like to see the frequency of: *" << endl;
			cout << "*****************************************************************" << endl;
			cout << endl;
			std::cin >> groceryItem;

			// If user enters item that is not in the files
			if (itemFrequency.find(groceryItem) == itemFrequency.end()) {
				cout << "This item is not in our files." << endl;
			}
			// If user enters item that is in files
			else {
				cout << groceryItem << " were sold " << itemFrequency[groceryItem] << " times." << endl;
			}
		}

		// if user selects option 2 on menu
		else if (userInput == 2) {
			cout << endl;
			cout << "********************************************************" << endl;
			cout << "*            Items Sold And Amount Sold                *" << endl;
			cout << "********************************************************" << endl;
			cout << endl;

			for (auto i : itemFrequency) {
				cout << i.first << " " << i.second << endl;
			}
		}

		// if user selects option 3 on menu
		else if (userInput == 3) {
			cout << endl;
			cout << "********************************************************" << endl;
			cout << "*             Items Sold And Histogram                 *" << endl;
			cout << "********************************************************" << endl;
			cout << endl;

			for (auto i : itemFrequency) {
				cout << i.first << " ";
				for (int j = 0; j < i.second; j++) {
					cout << "*";
				}
				cout << endl;
			}
		}

		// if user selects option 4 on menu. Exits program
		else if (userInput == 4) {
			cout << "Exiting Corner Grocer System." << endl;
			runMenu = false;
		}


	} while (runMenu == true);
}